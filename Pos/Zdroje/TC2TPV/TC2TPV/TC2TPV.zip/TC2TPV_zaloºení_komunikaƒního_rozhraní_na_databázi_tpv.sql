IF NOT EXISTS (select top 1 1 from sys.sysobjects where name = 'tpvg_tc2tpv_config')
BEGIN
	CREATE TABLE dbo.tpvg_tc2tpv_config (
		klic_config int identity,
		nazev_pole_tpv varchar(255),
		nazev_pole_tc varchar(255),
		poznamka varchar(500),
		typ varchar(1),
		velikost int
	)

	GRANT SELECT, INSERT, UPDATE, DELETE ON dbo.tpvg_tc2tpv_config TO PUBLIC

	-- alter table tpvg_tc2tpv_config add typ varchar(1)
	-- alter table tpvg_tc2tpv_config add velikost int
END

-- select * from tpv_c2t_import
GO

delete from tpvg_tc2tpv_config
-- sp_help tpv_c2t_import

insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'atr_nazvu_1', '', 'Atribut n�zvu polo�ky 1', 'S', 30
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'atr_nazvu_2', '', 'Atribut n�zvu polo�ky 2', 'S', 30
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'atr_nazvu_3', '', 'Atribut n�zvu polo�ky 3', 'S', 30
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user1', 'tc_u1', 'U�ivatelsk� pole 1', 'S', 100
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user2', 'tc_u2', 'U�ivatelsk� pole 2', 'S', 100
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user3', 'tc_u3', 'U�ivatelsk� pole 3', 'S', 100
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user4', '', 'U�ivatelsk� pole 4', 'F', 0
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user5', '', 'U�ivatelsk� pole 5', 'F', 0
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user6', '', 'U�ivatelsk� pole 6', 'I', 0
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user7', '', 'U�ivatelsk� pole 7', 'I', 0
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user8', '', 'U�ivatelsk� pole 8', 'S', 100
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user9', '', 'U�ivatelsk� pole 9', 'S', 100
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user10', '', 'U�ivatelsk� pole 10', 'S', 100
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user11', '', 'U�ivatelsk� pole 11', 'S', 60
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user12', '', 'U�ivatelsk� pole 12', 'S', 60
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user13', '', 'U�ivatelsk� pole 13', 'S', 60
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user14', '', 'U�ivatelsk� pole 14', 'F', 0
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user1s', '', 'U�ivatelsk� pole struktury 1', 'S', 100
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user2s', '', 'U�ivatelsk� pole struktury 2', 'S', 100
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user3s', '', 'U�ivatelsk� pole struktury 3', 'S', 100
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'user4s', '', 'U�ivatelsk� pole struktury 4', 'F', 0
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'plocha', '', 'Plocha', 'F', 0
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'objem', '', 'Objem', 'F', 0
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'poznamka', '', 'Pozn�mka polo�ky', 'S', 500
insert into tpvg_tc2tpv_config (nazev_pole_tpv, nazev_pole_tc, poznamka, typ, velikost) select 'poznamkas', '', 'Pozn�mka struktury', 'S', 100

GO
-- select * from vtp_polozka
-- select * from tpvg_tc2tpv_config
-- select * from tpv_c2t_cfg
-- select * from tpv_c2t_import_hlav order by klic_imp_hlav desc
-- select * from tpv_c2t_import where klic_imp_hlav = 23
-- delete from tpv_c2t_import where klic_imp_hlav = 22
-- delete from tpv_c2t_import_hlav where klic_imp_hlav = 22
-- sp_help tpv_c2t_import
-- select * from tpv_c2t_import_dok
-- select * from tpv_c2t_import
-- select * from sys.sysobjects where name like '%dok%' and xtype = 'U'
-- sp_help tpv_c2t_import_dok
-- select * from tpv_tmp_c2t_import_dok

/*
-- DELETE testovacich dat
-- select * from alternazev

declare @k table (klic int)

insert into @k (klic) select klic_polozky from polozka where alter_nazev like 'A0%' or alter_nazev like 'B0%' or alter_nazev like 'C0%' or alter_nazev like 'N0%'

delete from structur where klic_polozky in (select klic from @k)
delete from structur where klic_komponenty in (select klic from @k)
delete from partmod where klic_polozky in (select klic from @k)
delete from opmod where klic_polozky in (select klic from @k)
delete from porizeni_pol where klic_polozky in (select klic from @k)
delete from tpv_polozka_ext where klic_polozky in (select klic from @k)
delete from alternazev where alter_nazev like 'A0%' or alter_nazev like 'B0%' or alter_nazev like 'C0%' or alter_nazev like 'N0%'
delete from polozka where klic_polozky in (select klic from @k)
*/

/*
-- Enable xp cmdshell pro import priloh

-- To allow advanced options to be changed.
EXEC sp_configure 'show advanced options', 1
GO
-- To update the currently configured value for advanced options.
RECONFIGURE
GO
-- To enable the feature.
EXEC sp_configure 'xp_cmdshell', 1
GO
-- To update the currently configured value for this feature.
RECONFIGURE
GO

*/
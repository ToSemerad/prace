/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tccom;

import java.sql.SQLException;
import tc2tpv.InvalidParameterException;
import tc2tpv.InvalidParameterTypeException;
import tc2tpv.MaterialNotFoundException;
import tc2tpv.TC2TPV;
import tc2tpv.TPVItem;
import tc2tpv.TPVSQL;

/**
 *
 * @author TPV
 */
public class test {
    
    
    public static void main(String[] args) throws ClassNotFoundException, SQLException, MaterialNotFoundException, InvalidParameterException, InvalidParameterTypeException {
        TPVSQL sql = new TPVSQL("94.138.109.185:21433", "TPV2000_TC", "sa", "Sa99");
        
        TPVItem a1 = new TPVItem(TPVItem.TYPE_ASSEMBLY, "A01", "Vrcholová sestava A01", "R01");
        a1.setParameter("tc_u1", "Parametr U1");
        a1.setParameter("tc_u2", "Parametr U2");
        a1.setParameter("tc_u3", "Parametr U3");
        //a1.addFile("C:\\Users\\TPV\\Desktop\\Workfolder\\t1.pdf");
        
        TPVItem b1 = new TPVItem(TPVItem.TYPE_ASSEMBLY, "B01", "Podsestava B01", "R01");
        TPVItem b2 = new TPVItem(TPVItem.TYPE_ASSEMBLY, "B02", "Podsestava B02", "R01");
        TPVItem b3 = new TPVItem(TPVItem.TYPE_ASSEMBLY, "B03", "Podsestava B03", "R01");
        
        a1.addBomLine(b1, 1);
        a1.addBomLine(b2, 2);
        a1.addBomLine(b3, 1);
        
        TPVItem c1 = new TPVItem(TPVItem.TYPE_SEMI, "C01", "Polotovar C01", "R01");
        TPVItem c2 = new TPVItem(TPVItem.TYPE_SEMI, "C02", "Polotovar C02", "R01");
        TPVItem c3 = new TPVItem(TPVItem.TYPE_SEMI, "C03", "Polotovar C03", "R01");
        TPVItem c4 = new TPVItem(TPVItem.TYPE_SEMI, "C04", "Polotovar C04", "R01");
        TPVItem c5 = new TPVItem(TPVItem.TYPE_SEMI, "C05", "Polotovar C05", "R01");
        TPVItem c6 = new TPVItem(TPVItem.TYPE_SEMI, "C06", "Polotovar C06", "R01");
        TPVItem c7 = new TPVItem(TPVItem.TYPE_SEMI, "C07", "Polotovar C07", "R01");
        
        c1.setMaterial("Plech 1mm", 2);
        c2.setMaterial("Plech 1mm", 1);
        c3.setMaterial("Plech 3mm", 1);
        
        TPVItem n1 = new TPVItem(TPVItem.TYPE_NORM, "N01", "Nakupovaná položka 1", "R01");
        TPVItem n2 = new TPVItem(TPVItem.TYPE_NORM, "N02", "Nakupovaná položka 2", "R01");
        TPVItem n3 = new TPVItem(TPVItem.TYPE_NORM, "N03", "Nakupovaná položka 3", "R01");
        TPVItem n4 = new TPVItem(TPVItem.TYPE_NORM, "N04", "Nakupovaná položka 4", "R01");
        
        b1.addBomLine(c1, 3);
        b1.addBomLine(c2, 2);
        b1.addBomLine(c3, 2);
        b2.addBomLine(c4, 2);
        b2.addBomLine(c5, 1);
        b3.addBomLine(c6, 1);
        b3.addBomLine(c7, 2);
        b3.addBomLine(c1, 1);
        
        b1.addBomLine(n1, 5);
        b1.addBomLine(n2, 2);
        b2.addBomLine(n1, 3);
        b2.addBomLine(n3, 1);
        b3.addBomLine(n1, 1);
        b3.addBomLine(n2, 1);
        b3.addBomLine(n3, 1);
        b3.addBomLine(n4, 1);
        
        a1.printTree();
        int klicImportu = a1.insertItemToTPV();
        String err = TC2TPV.provedKontrolu(klicImportu);
        if (err.equals("")) {
            TC2TPV.provedImport(klicImportu);
        } else {
            // Chyba pro kontrole
            System.out.println(err);
        }
    }
}
